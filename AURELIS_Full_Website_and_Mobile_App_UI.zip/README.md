AURELIS FULL UI PACKAGE

WEBSITE
- Home
- Jets catalogue
- Yachts catalogue
- Asset detail page
- Private concierge inquiry
- Saved assets
- Admin dashboard

MOBILE APP
- Discover
- Jets
- Yachts
- Saved
- Profile
- Listing detail

Open index.html for the website.
Open mobile/home.html for the mobile app mockup.

This is a front-end UI prototype. Production features still need a backend, authentication,
database, real listing data, CRM/email integration, payments where appropriate, and licensed media.
